MODDIR=${0%/*}

"$MODDIR/lspctl" stop --emulated-soft-reboot
